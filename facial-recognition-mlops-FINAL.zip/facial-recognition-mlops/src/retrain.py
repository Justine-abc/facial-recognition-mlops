"""src/retrain.py — works with any number of images"""
import json, os
import tensorflow as tf
from tensorflow.keras.models import load_model
from tensorflow.keras.callbacks import EarlyStopping
import numpy as np
from PIL import Image

IMG_SIZE   = 224
BATCH_SIZE = 4

def retrain_model(dataset_dir, model_path, class_map_path, epochs=15, learning_rate=0.00005):
    classes = sorted([d for d in os.listdir(dataset_dir)
                      if os.path.isdir(os.path.join(dataset_dir, d))])
    class_to_idx = {c: i for i, c in enumerate(classes)}
    n_classes = len(classes)

    X, y = [], []
    for cls in classes:
        cls_dir = os.path.join(dataset_dir, cls)
        for fname in os.listdir(cls_dir):
            if not fname.lower().endswith((".jpg", ".jpeg", ".png")):
                continue
            try:
                img = Image.open(os.path.join(cls_dir, fname)).convert("RGB")
                img = img.resize((IMG_SIZE, IMG_SIZE))
                arr = np.array(img, dtype=np.float32) / 255.0
                X.append(arr)
                y.append(class_to_idx[cls])
            except:
                pass

    X = np.array(X)
    y = tf.keras.utils.to_categorical(y, num_classes=n_classes)

    model = load_model(model_path)
    if model.output_shape[-1] != n_classes:
        from tensorflow.keras.layers import Dense
        from tensorflow.keras.models import Model
        out = Dense(n_classes, activation="softmax")(model.layers[-2].output)
        model = Model(inputs=model.input, outputs=out)

    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=learning_rate),
        loss="categorical_crossentropy",
        metrics=["accuracy",
                 tf.keras.metrics.Precision(name="precision"),
                 tf.keras.metrics.Recall(name="recall")]
    )

    use_val = len(X) >= 10
    hist = model.fit(
        X, y,
        epochs=epochs,
        batch_size=BATCH_SIZE,
        validation_split=0.2 if use_val else 0.0,
        callbacks=[EarlyStopping(
            monitor="val_loss" if use_val else "loss",
            patience=5,
            restore_best_weights=True
        )],
        verbose=1
    )

    model.save(model_path)
    mapping = {str(i): c for i, c in enumerate(classes)}
    with open(class_map_path, "w") as f:
        json.dump(mapping, f, indent=2)

    acc_key = "val_accuracy" if use_val else "accuracy"
    return {
        "val_accuracy":   round(float(max(hist.history[acc_key])) * 100, 2),
        "val_loss":       round(float(min(hist.history.get("val_loss", hist.history["loss"]))), 4),
        "epochs_trained": len(hist.history["loss"]),
        "classes":        classes,
    }
