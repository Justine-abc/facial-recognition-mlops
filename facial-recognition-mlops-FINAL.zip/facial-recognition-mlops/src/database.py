"""src/database.py — SQLite persistence for uploaded images."""

import sqlite3
from datetime import datetime

DB_PATH = "data/uploads.db"


def _conn():
    return sqlite3.connect(DB_PATH)


def init_db():
    with _conn() as con:
        con.execute("""
            CREATE TABLE IF NOT EXISTS uploads (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                label     TEXT    NOT NULL,
                filename  TEXT    NOT NULL,
                filepath  TEXT    NOT NULL,
                uploaded_at TEXT  DEFAULT (datetime('now'))
            )
        """)
        con.commit()


def save_upload(label: str, filename: str, filepath: str):
    with _conn() as con:
        con.execute(
            "INSERT INTO uploads (label, filename, filepath) VALUES (?, ?, ?)",
            (label, filename, filepath),
        )
        con.commit()


def get_all_uploads():
    with _conn() as con:
        rows = con.execute(
            "SELECT id, label, filename, uploaded_at FROM uploads ORDER BY id DESC LIMIT 100"
        ).fetchall()
    return [{"id": r[0], "label": r[1], "filename": r[2], "uploaded_at": r[3]} for r in rows]


def get_upload_stats():
    with _conn() as con:
        total = con.execute("SELECT COUNT(*) FROM uploads").fetchone()[0]
        by_label = con.execute(
            "SELECT label, COUNT(*) as cnt FROM uploads GROUP BY label ORDER BY cnt DESC"
        ).fetchall()
        recent = con.execute(
            "SELECT label, filename, uploaded_at FROM uploads ORDER BY id DESC LIMIT 5"
        ).fetchall()

    return {
        "total_uploads": total,
        "by_label": [{"label": r[0], "count": r[1]} for r in by_label],
        "recent":   [{"label": r[0], "filename": r[1], "uploaded_at": r[2]} for r in recent],
    }
