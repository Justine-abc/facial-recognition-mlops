"""src/prediction.py — Inference logic."""

import json
import numpy as np
from PIL import Image

IMG_SIZE = 224


def predict_face(image_path: str, model_path: str, class_map_path: str) -> dict:
    """
    Run inference on a single image.
    Returns label, confidence, and full probability distribution.
    """
    # Lazy import TF so the app boots fast even without GPU
    from tensorflow.keras.models import load_model
    from tensorflow.keras.preprocessing.image import load_img, img_to_array

    model = load_model(model_path)

    with open(class_map_path) as f:
        class_names = json.load(f)   # {"0": "Edwin", "1": "Glory", ...}

    img       = load_img(image_path, target_size=(IMG_SIZE, IMG_SIZE))
    img_array = img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    preds = model.predict(img_array, verbose=0)[0]
    idx   = int(np.argmax(preds))

    return {
        "label":            class_names[str(idx)],
        "confidence":       float(round(float(preds[idx]) * 100, 2)),
        "all_probabilities": {
            class_names[str(i)]: float(round(float(preds[i]) * 100, 2))
            for i in range(len(preds))
        }
    }
