Place facial_recognition_model.keras, class_names.json, training_config.json here
